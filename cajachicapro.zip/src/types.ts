export type UserRole = 'ADMIN' | 'JEFE_AREA';

export type ExpenseStatus = 'Pendiente' | 'En revisión' | 'Observado' | 'Aprobado' | 'Rechazado' | 'Pagado';
export type RiskColor = 'verde' | 'amarillo' | 'rojo';

export interface User {
  id: string;
  nombre: string;
  rol: UserRole;
  area: string;
  correo: string;
  avatar?: string;
}

export interface Expense {
  id: string;
  fecha: string;
  monto: number;
  moneda: 'PEN' | 'USD';
  proveedor_nombre: string;
  proveedor_ruc?: string;
  codigo_comprobante: string;
  categoria: string;
  centro_costos?: string;
  area: string;
  solicitante: string;
  solicitanteId: string;
  descripcion: string;
  evidencia_imagen: string;
  estado: ExpenseStatus;
  riesgo_color: RiskColor;
  riesgo_motivos: string[];
  comentarios_admin?: string;
  respuesta_solicitante?: string;
  pago?: {
    metodo: 'Yape' | 'Transferencia' | 'Efectivo' | 'Otro';
    nro_operacion: string;
    fecha_pago: string;
  };
  createdAt: string;
}

export interface BlockedProvider {
  id: string;
  ruc_o_nombre: string;
  motivo: string;
  fecha: string;
  creado_por: string;
}

export interface AppSettings {
  repeatThreshold: number; // X times
  repeatDays: number; // in Y days
  limitPerCategory: Record<string, number>;
}
