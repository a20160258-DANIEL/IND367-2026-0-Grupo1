import { Expense, User, BlockedProvider } from './types';

export const MOCK_USERS: User[] = [
  {
    id: 'u1',
    nombre: 'Admin User',
    rol: 'ADMIN',
    area: 'Administración',
    correo: 'admin@cajachicapro.com',
    avatar: 'https://i.pravatar.cc/150?u=admin'
  },
  {
    id: 'u2',
    nombre: 'Juan Ferrari',
    rol: 'JEFE_AREA',
    area: 'Mantenimiento',
    correo: 'juan.ferrari@cajachicapro.com',
    avatar: 'https://i.pravatar.cc/150?u=juan'
  },
  {
    id: 'u3',
    nombre: 'Carla Ruiz',
    rol: 'JEFE_AREA',
    area: 'Operaciones',
    correo: 'carla.ruiz@cajachicapro.com',
    avatar: 'https://i.pravatar.cc/150?u=carla'
  }
];

export const MOCK_BLOCKED_PROVIDERS: BlockedProvider[] = [
  {
    id: 'b1',
    ruc_o_nombre: 'Ferretería El Engaño',
    motivo: 'Facturas falsas detectadas anteriormente',
    fecha: '2025-12-01',
    creado_por: 'Admin User'
  }
];

export const MOCK_EXPENSES: Expense[] = [
  {
    id: 'e1',
    fecha: '2026-02-13',
    monto: 1280.50,
    moneda: 'PEN',
    proveedor_nombre: 'Papelería Central',
    codigo_comprobante: 'B001-0001234',
    categoria: 'Suministros de oficina',
    area: 'Mantenimiento',
    solicitante: 'Carlos Bazan',
    solicitanteId: 'u2',
    descripcion: 'Compra de útiles de oficina para el equipo',
    evidencia_imagen: 'https://picsum.photos/seed/receipt1/400/600',
    estado: 'Pendiente',
    riesgo_color: 'amarillo',
    riesgo_motivos: ['Compra recurrente (4 veces en 30 días)'],
    createdAt: '2026-02-13T10:00:00Z'
  },
  {
    id: 'e2',
    fecha: '2026-02-12',
    monto: 85.00,
    moneda: 'PEN',
    proveedor_nombre: 'Restaurante Doña Goya',
    codigo_comprobante: 'F002-0005678',
    categoria: 'Alimentación',
    area: 'Ventas',
    solicitante: 'Juan Ferrari',
    solicitanteId: 'u2',
    descripcion: 'Almuerzo con cliente potencial',
    evidencia_imagen: 'https://picsum.photos/seed/receipt2/400/600',
    estado: 'Aprobado',
    riesgo_color: 'verde',
    riesgo_motivos: [],
    createdAt: '2026-02-12T14:30:00Z'
  },
  {
    id: 'e3',
    fecha: '2026-02-11',
    monto: 2500.00,
    moneda: 'PEN',
    proveedor_nombre: 'Ferretería El Engaño',
    codigo_comprobante: 'B005-0009999',
    categoria: 'Ferretería',
    area: 'Mantenimiento',
    solicitante: 'Carlos Bazan',
    solicitanteId: 'u2',
    descripcion: 'Herramientas varias',
    evidencia_imagen: 'https://picsum.photos/seed/receipt3/400/600',
    estado: 'Observado',
    riesgo_color: 'rojo',
    riesgo_motivos: ['Proveedor en lista negra', 'Monto excede límite diario'],
    comentarios_admin: 'Falta comprobante físico y el proveedor está bloqueado.',
    createdAt: '2026-02-11T09:00:00Z'
  }
];
