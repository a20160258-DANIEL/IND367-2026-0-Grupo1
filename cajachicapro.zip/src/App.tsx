/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  Home, 
  FileText, 
  Plus, 
  BarChart3, 
  User as UserIcon, 
  ChevronLeft, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Camera,
  ArrowRight,
  Download,
  ShieldAlert,
  Settings,
  LogOut,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { format, subDays, isWithinInterval, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

import { cn } from './lib/utils';
import { 
  User, 
  Expense, 
  ExpenseStatus, 
  RiskColor, 
  BlockedProvider,
  AppSettings
} from './types';
import { MOCK_USERS, MOCK_EXPENSES, MOCK_BLOCKED_PROVIDERS } from './mockData';

// --- Components ---

const StatusBadge = ({ status }: { status: ExpenseStatus }) => {
  const styles = {
    'Pendiente': 'bg-orange-100 text-orange-700',
    'En revisión': 'bg-blue-100 text-blue-700',
    'Observado': 'bg-yellow-100 text-yellow-700',
    'Aprobado': 'bg-green-100 text-green-700',
    'Rechazado': 'bg-red-100 text-red-700',
    'Pagado': 'bg-emerald-100 text-emerald-700',
  };
  return (
    <span className={cn("px-3 py-1 rounded-full text-[10px] font-bold uppercase", styles[status])}>
      {status}
    </span>
  );
};

// --- Main App ---

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('inicio');
  const [expenses, setExpenses] = useState<Expense[]>(MOCK_EXPENSES);
  const [blockedProviders] = useState<BlockedProvider[]>(MOCK_BLOCKED_PROVIDERS);
  const [settings] = useState<AppSettings>({
    repeatThreshold: 3,
    repeatDays: 30,
    limitPerCategory: { 'Ferretería': 500, 'Alimentación': 200 }
  });
  const [viewingExpense, setViewingExpense] = useState<Expense | null>(null);
  const [isClosing, setIsClosing] = useState(false);

  // Auto-login for demo
  useEffect(() => {
    if (!currentUser) setCurrentUser(MOCK_USERS[0]);
  }, []);

  const isAdmin = currentUser?.rol === 'ADMIN';

  // --- Logic ---

  const detectRisk = (newExpense: Partial<Expense>): { color: RiskColor; reasons: string[] } => {
    const reasons: string[] = [];
    let color: RiskColor = 'verde';

    // 1. Duplicity
    const isDuplicate = expenses.some(e => 
      e.codigo_comprobante === newExpense.codigo_comprobante &&
      e.proveedor_nombre === newExpense.proveedor_nombre &&
      e.monto === newExpense.monto &&
      e.fecha === newExpense.fecha
    );
    if (isDuplicate) {
      reasons.push('Posible duplicidad (Mismos datos detectados)');
      color = 'rojo';
    }

    // 2. Blocked Provider
    const isBlocked = blockedProviders.some(p => 
      p.ruc_o_nombre.toLowerCase() === newExpense.proveedor_nombre?.toLowerCase()
    );
    if (isBlocked) {
      reasons.push('Proveedor en lista negra');
      color = 'rojo';
    }

    // 3. Repetitive Pattern
    const recentExpenses = expenses.filter(e => 
      e.solicitanteId === currentUser?.id &&
      e.categoria === newExpense.categoria &&
      isWithinInterval(parseISO(e.fecha), {
        start: subDays(new Date(), settings.repeatDays),
        end: new Date()
      })
    );
    if (recentExpenses.length >= settings.repeatThreshold) {
      reasons.push(`Compra recurrente (${recentExpenses.length + 1} veces en ${settings.repeatDays} días)`);
      if (color !== 'rojo') color = 'amarillo';
    }

    return { color, reasons };
  };

  const [showSuccess, setShowSuccess] = useState(false);

  const handleAddExpense = (newExpense: any) => {
    const risk = detectRisk(newExpense);
    const expense: Expense = {
      ...newExpense,
      id: `e${expenses.length + 1}`,
      solicitante: currentUser?.nombre || '',
      solicitanteId: currentUser?.id || '',
      area: currentUser?.area || '',
      estado: 'Pendiente',
      riesgo_color: risk.color,
      riesgo_motivos: risk.reasons,
      createdAt: new Date().toISOString(),
    };
    setExpenses([expense, ...expenses]);
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setActiveTab('inicio');
    }, 2000);
  };

  const [decisionFeedback, setDecisionFeedback] = useState<{ status: 'Aprobado' | 'Rechazado', expense: Expense } | null>(null);

  const handleUpdateStatus = (id: string, status: ExpenseStatus, comment?: string) => {
    const expense = expenses.find(e => e.id === id);
    if (!expense) return;

    setExpenses(expenses.map(e => e.id === id ? { ...e, estado: status, comentarios_admin: comment } : e));
    
    if (status === 'Aprobado' || status === 'Rechazado') {
      setDecisionFeedback({ status: status as 'Aprobado' | 'Rechazado', expense: { ...expense, estado: status } });
    }
    
    setViewingExpense(null);
  };

  const renderDecisionFeedback = () => {
    if (!decisionFeedback) return null;
    const isApproved = decisionFeedback.status === 'Aprobado';

    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className={cn(
          "fixed inset-0 z-[70] flex flex-col items-center justify-center p-6 text-white",
          isApproved ? "bg-gradient-to-b from-emerald-400 to-emerald-700" : "bg-gradient-to-b from-red-500 to-red-800"
        )}
      >
        {/* Background Patterns - Simulating the shapes in Image 10/11 */}
        <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <div 
              key={i} 
              className="absolute bg-black w-32 h-48 rounded-[40px]" 
              style={{ 
                top: `${i * 20}%`, 
                left: i % 2 === 0 ? '-10%' : '80%',
                transform: `rotate(${i * 15}deg)`
              }} 
            />
          ))}
        </div>

        <div className="relative z-10 w-full max-w-xs flex flex-col items-center space-y-8">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={cn(
              "px-8 py-4 rounded-full font-bold text-xl shadow-2xl",
              isApproved ? "bg-blue-800" : "bg-red-900"
            )}
          >
            Se {isApproved ? 'aprobó' : 'rechazó'} el gasto
          </motion.div>

          {!isApproved && (
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-2xl font-bold text-red-200"
            >
              Pasa a revisión
            </motion.p>
          )}

          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-white/20 backdrop-blur-xl border border-white/30 p-6 rounded-[32px] w-full shadow-2xl"
          >
            <h4 className="font-bold text-lg text-white">{decisionFeedback.expense.categoria}</h4>
            <p className="text-sm opacity-80">{decisionFeedback.expense.solicitante}</p>
            <div className="mt-4">
              <p className="text-4xl font-black tracking-tighter">
                {decisionFeedback.expense.monto.toLocaleString()} $
              </p>
              <p className="text-xs opacity-70 mt-1">
                {decisionFeedback.expense.proveedor_nombre} {format(parseISO(decisionFeedback.expense.fecha), 'dd/MM/yyyy')}
              </p>
            </div>
          </motion.div>

          <motion.button 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            onClick={() => setDecisionFeedback(null)}
            className="w-full bg-blue-800 text-white py-4 rounded-2xl font-bold text-lg shadow-xl active:scale-95 transition-transform"
          >
            Continuar
          </motion.button>
        </div>
      </motion.div>
    );
  };

  // --- Views ---

  const renderInicio = () => {
    const dailyLimit = 1500;
    const usedToday = expenses
      .filter(e => e.fecha === format(new Date(), 'yyyy-MM-dd') && e.estado !== 'Rechazado')
      .reduce((acc, curr) => acc + curr.monto, 0);
    const progress = Math.min((usedToday / dailyLimit) * 100, 100);

    const pendingCount = expenses.filter(e => e.estado === 'Pendiente').length;
    const approvedToday = expenses.filter(e => e.estado === 'Aprobado' && e.fecha === format(new Date(), 'yyyy-MM-dd')).length;
    const rejectedCount = expenses.filter(e => e.estado === 'Rechazado').length;

    return (
      <div className="p-4 space-y-6 pb-24">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              Hola, {currentUser?.nombre.split(' ')[0]}
              <span className="text-[10px] bg-gray-200 px-2 py-0.5 rounded uppercase font-bold text-gray-600">
                {currentUser?.rol}
              </span>
            </h1>
            <p className="text-gray-500 text-sm capitalize">
              {format(new Date(), "EEEE d 'Feb' yyyy", { locale: es })}
            </p>
          </div>
          <button onClick={() => setCurrentUser(MOCK_USERS.find(u => u.rol !== currentUser?.rol) || null)} className="p-2 bg-gray-100 rounded-full">
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Budget Card */}
        <div className="bg-gradient-to-br from-emerald-400 to-emerald-600 p-5 rounded-3xl text-white shadow-xl shadow-emerald-200 relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-lg font-medium opacity-90">Estado de caja</h2>
            <p className="text-sm opacity-75">Saldo disponible</p>
            <div className="text-3xl font-bold mt-1">219,5 US$</div>
            
            <div className="mt-6">
              <div className="flex justify-between text-xs mb-1 font-medium">
                <span>Progreso diario</span>
                <span>{progress.toFixed(0)}%</span>
              </div>
              <div className="h-2 bg-white/30 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  className="h-full bg-yellow-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 mt-4 pt-4 border-t border-white/20 text-xs">
              <div>
                <p className="opacity-75">Límite diario</p>
                <p className="font-bold">{dailyLimit} US$</p>
              </div>
              <div className="text-right">
                <p className="opacity-75">Usado hoy</p>
                <p className="font-bold">{usedToday} US$</p>
              </div>
            </div>
          </div>
          <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
        </div>

        {/* Alerts */}
        <div className="space-y-3">
          <h3 className="font-bold text-lg">Alertas Urgentes</h3>
          {pendingCount > 0 && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
              <div>
                <p className="text-sm font-bold text-red-800">{pendingCount} gastos pendientes requieren atención inmediata</p>
                <p className="text-xs text-red-600 opacity-75">Hace 15 min</p>
              </div>
            </div>
          )}
          {progress > 80 && (
            <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded-r-xl flex items-start gap-3">
              <Clock className="w-5 h-5 text-yellow-500 mt-0.5" />
              <div>
                <p className="text-sm font-bold text-yellow-800">Límite diario al {progress.toFixed(0)}% ({usedToday} de {dailyLimit})</p>
                <p className="text-xs text-yellow-600 opacity-75">Hace 1 hora</p>
              </div>
            </div>
          )}
        </div>

        {/* Summary Grid */}
        <div className="space-y-3">
          <h3 className="font-bold text-lg">Resumen de hoy</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between h-32">
              <div>
                <p className="text-gray-500 text-sm">Gastos del día</p>
                <p className="text-2xl font-bold mt-1">{usedToday} $</p>
              </div>
              <div className="flex justify-between items-end">
                <p className="text-[10px] text-gray-400">De ${dailyLimit} límite</p>
                <div className="p-2 bg-gray-100 rounded-lg">
                  <FileText className="w-5 h-5 text-gray-400" />
                </div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between h-32">
              <div>
                <p className="text-gray-500 text-sm">Pendientes</p>
                <p className="text-2xl font-bold mt-1">{pendingCount}</p>
              </div>
              <div className="flex justify-between items-end">
                <p className="text-[10px] text-gray-400">2 urgentes</p>
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <Clock className="w-5 h-5 text-yellow-600" />
                </div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between h-32">
              <div>
                <p className="text-gray-500 text-sm">Aprobados</p>
                <p className="text-2xl font-bold mt-1">{approvedToday}</p>
              </div>
              <div className="flex justify-between items-end">
                <p className="text-[10px] text-gray-400">Hoy</p>
                <div className="p-2 bg-green-100 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
              </div>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between h-32">
              <div>
                <p className="text-gray-500 text-sm">Rechazados</p>
                <p className="text-2xl font-bold mt-1">{rejectedCount}</p>
              </div>
              <div className="flex justify-between items-end">
                <p className="text-[10px] text-gray-400">Requieren seguimiento</p>
                <div className="p-2 bg-red-100 rounded-lg">
                  <XCircle className="w-5 h-5 text-red-600" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {isAdmin && (
          <button 
            onClick={() => setIsClosing(true)}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-200 active:scale-95 transition-transform"
          >
            Cierre de hoy
          </button>
        )}
      </div>
    );
  };

  const renderGastos = () => {
    const filteredExpenses = expenses.filter(e => isAdmin || e.solicitanteId === currentUser?.id);
    
    return (
      <div className="pb-24">
        <div className="bg-slate-900 text-white p-6 pt-12 rounded-b-[40px] flex items-center justify-center relative">
          <h2 className="text-xl font-bold tracking-widest uppercase">Para Revisar</h2>
        </div>

        <div className="p-4 space-y-4">
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            <span className="bg-red-500 text-white px-4 py-1.5 rounded-xl text-sm font-medium">Riesgo</span>
            <span className="bg-yellow-100 text-yellow-800 px-4 py-1.5 rounded-xl text-sm font-medium">Pendientes</span>
            <span className="bg-green-100 text-green-800 px-4 py-1.5 rounded-xl text-sm font-medium">Aprobados</span>
          </div>

          <div className="space-y-4">
            {filteredExpenses.map(expense => (
              <motion.div 
                key={expense.id}
                layoutId={expense.id}
                onClick={() => setViewingExpense(expense)}
                className={cn(
                  "bg-white p-4 rounded-2xl border-l-4 shadow-sm relative",
                  expense.riesgo_color === 'rojo' ? "border-l-red-500" : 
                  expense.riesgo_color === 'amarillo' ? "border-l-yellow-400" : "border-l-green-400"
                )}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-gray-800">{expense.categoria}</h4>
                    <p className="text-xs text-gray-400">{expense.solicitante}</p>
                  </div>
                  <Clock className="w-4 h-4 text-gray-300" />
                </div>
                
                <div className="mt-2">
                  <p className="text-2xl font-bold">{expense.monto.toLocaleString()} $</p>
                  <p className="text-[10px] text-gray-400">{expense.proveedor_nombre} {format(parseISO(expense.fecha), 'dd/MM/yyyy')}</p>
                </div>

                {expense.estado === 'Observado' && (
                  <div className="mt-3 text-xs text-red-500 font-medium italic">
                    Obs: {expense.comentarios_admin}
                  </div>
                )}

                {isAdmin && expense.estado === 'Pendiente' && (
                  <div className="flex gap-2 mt-4">
                    <button className="flex-1 py-2 border border-green-500 text-green-600 rounded-lg text-xs font-bold">Aprobar</button>
                    <button className="flex-1 py-2 border border-red-500 text-red-600 rounded-lg text-xs font-bold">Rechazar</button>
                  </div>
                )}

                {expense.riesgo_color === 'rojo' && (
                  <div className="absolute top-4 right-4">
                    <AlertCircle className="w-5 h-5 text-red-500" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderRegistrar = () => {
    return (
      <div className="p-4 pb-24 space-y-6">
        <div className="flex items-center gap-4">
          <ChevronLeft className="w-6 h-6" onClick={() => setActiveTab('inicio')} />
          <div>
            <h2 className="text-xl font-bold uppercase">Registrar Gasto</h2>
            <p className="text-xs text-gray-500">Complete los datos del comprobante</p>
          </div>
        </div>

        <div className="bg-emerald-50 border-2 border-dashed border-emerald-200 rounded-3xl p-8 flex flex-col items-center justify-center text-center space-y-3">
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
            <Camera className="w-8 h-8 text-emerald-500" />
          </div>
          <div>
            <p className="font-bold text-emerald-800">Comprobante</p>
            <p className="text-[10px] text-emerald-600">Adjunta una fotografía clara y legible del recibo o boleta</p>
          </div>
          <div className="bg-white border border-emerald-100 px-6 py-3 rounded-2xl shadow-sm flex items-center gap-2 cursor-pointer">
            <Plus className="w-4 h-4 text-emerald-500" />
            <span className="text-xs font-bold text-gray-600">Seleccionar archivo</span>
          </div>
          <p className="text-[10px] text-gray-400">JPG, PNG o PDF Máx. 5MB</p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-2 text-red-800 font-bold">
            <CheckCircle2 className="w-5 h-5 text-red-600" />
            <h3>Datos requeridos</h3>
          </div>
          <p className="text-[10px] text-gray-400 -mt-3">Campo obligatorio para el registro</p>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-bold text-gray-700 block mb-1">Descripción del gasto <span className="text-red-500">*</span></label>
              <input type="text" placeholder="Ejemplo: Compra de útiles de oficina" className="input-field" />
            </div>
            <div>
              <label className="text-sm font-bold text-gray-700 block mb-1">Código o serie del comprobante <span className="text-red-500">*</span></label>
              <input type="text" placeholder="Ejemplo: B001-00123456" className="input-field" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-bold text-gray-700 block mb-1">Monto total (S/) <span className="text-red-500">*</span></label>
                <input type="number" placeholder="0.00" className="input-field" />
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700 block mb-1">Fecha del gasto <span className="text-red-500">*</span></label>
                <input type="date" className="input-field" defaultValue={format(new Date(), 'yyyy-MM-dd')} />
              </div>
            </div>
          </div>
        </div>

        <button 
          onClick={() => handleAddExpense({
            monto: 150,
            categoria: 'Ferretería',
            proveedor_nombre: 'Ferretería Local',
            codigo_comprobante: 'B001-999',
            fecha: format(new Date(), 'yyyy-MM-dd'),
            descripcion: 'Compra de prueba',
            evidencia_imagen: 'https://picsum.photos/seed/new/400/600'
          })}
          className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg active:scale-95 transition-transform"
        >
          Guardar Registro
        </button>

        <AnimatePresence>
          {showSuccess && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 z-[100] bg-white/90 backdrop-blur-md flex flex-col items-center justify-center p-8 text-center"
            >
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 className="w-12 h-12 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Registro guardado</h3>
              <p className="text-gray-500">Tu gasto ha sido registrado exitosamente y está pendiente de revisión.</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  const renderIndicadores = () => {
    const data = [
      { name: 'Manten.', value: 5800 },
      { name: 'Operac.', value: 4200 },
      { name: 'Ventas', value: 3500 },
      { name: 'Logist.', value: 2800 },
      { name: 'Admin.', value: 1800 },
    ];

    return (
      <div className="p-4 pb-24 space-y-6">
        <div className="bg-slate-900 text-white p-6 -mx-4 -mt-4 rounded-b-[40px]">
          <h2 className="text-2xl font-bold">INDICADORES</h2>
          <p className="text-xs opacity-70">Control y patrones de caja chica</p>
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {['Semana', 'Mes', '3 meses', 'Año'].map(t => (
            <button key={t} className={cn("px-4 py-2 rounded-xl text-sm font-bold", t === 'Mes' ? "bg-slate-700 text-white" : "bg-gray-100 text-gray-500")}>
              {t}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-gray-500 text-xs">Total gastado</p>
            <p className="text-xl font-bold">$125,400</p>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-gray-500 text-xs">N° de gastos</p>
            <p className="text-xl font-bold">214</p>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-gray-500 text-xs">Promedio</p>
            <p className="text-xl font-bold">$58</p>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-gray-500 text-xs">Observados</p>
            <p className="text-xl font-bold">14 <span className="text-[10px] text-red-500 font-normal">6.5%</span></p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm space-y-4">
          <h3 className="font-bold">Gasto por Área</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                <Tooltip cursor={{ fill: '#f3f4f6' }} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#22c55e' : '#d1d5db'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-gray-50 -mx-4 p-4 space-y-4">
          <h3 className="font-bold">Artículos más repetidos</h3>
          <div className="bg-white rounded-2xl p-4 space-y-4">
            {[
              { name: 'Martillo', count: 9, area: 'Mantenimiento' },
              { name: 'Taxi', count: 8, area: 'Ventas' },
              { name: 'Tornillos', count: 7, area: 'Mantenimiento' }
            ].map((item, i) => (
              <div key={i} className="flex justify-between items-center border-b border-gray-100 pb-3 last:border-0 last:pb-0">
                <div>
                  <p className="font-bold text-sm">{item.name}</p>
                  <p className="text-[10px] text-gray-400">{item.count} veces - {item.area}</p>
                </div>
                <button className="text-[10px] font-bold text-gray-400 uppercase">Ver {'>'}</button>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="font-bold">Alertas de Patrón</h3>
          <div className="bg-red-50 border border-red-100 rounded-2xl p-4 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <p className="font-medium text-red-800">Martillo: 3 compras en 30 días (Mantenimiento)</p>
              <button className="text-red-600 font-bold underline">Revisar</button>
            </div>
            <div className="flex justify-between items-center text-xs">
              <p className="font-medium text-red-800">Taxi: 8 registros esta semana (Ventas)</p>
              <button className="text-red-600 font-bold underline">Revisar</button>
            </div>
          </div>
        </div>

        <button className="w-full bg-emerald-100 text-emerald-800 py-4 rounded-2xl font-bold flex items-center justify-center gap-2">
          <Download className="w-5 h-5" />
          Exportar Excel
        </button>
      </div>
    );
  };

  const renderPerfil = () => {
    return (
      <div className="p-4 pb-24 space-y-6">
        <div className="flex flex-col items-center space-y-4 pt-8">
          <div className="w-32 h-32 rounded-full border-4 border-white shadow-xl overflow-hidden">
            <img src={currentUser?.avatar} alt="Avatar" className="w-full h-full object-cover" />
          </div>
          <div className="text-center">
            <h2 className="text-2xl font-bold">{currentUser?.nombre}</h2>
            <p className="text-gray-500">{currentUser?.rol} - {currentUser?.area}</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="bg-white p-4 rounded-2xl shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <UserIcon className="w-5 h-5 text-blue-600" />
              </div>
              <span className="font-bold">Usuarios</span>
            </div>
            <ChevronLeft className="w-5 h-5 text-gray-300 rotate-180" />
          </div>
          <div className="bg-white p-4 rounded-2xl shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <ShieldAlert className="w-5 h-5 text-emerald-600" />
              </div>
              <span className="font-bold">Políticas</span>
            </div>
            <ChevronLeft className="w-5 h-5 text-gray-300 rotate-180" />
          </div>
          <div className="bg-white p-4 rounded-2xl shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertCircle className="w-5 h-5 text-red-600" />
              </div>
              <span className="font-bold">Lista negra de proveedores</span>
            </div>
            <ChevronLeft className="w-5 h-5 text-gray-300 rotate-180" />
          </div>
        </div>

        <button 
          onClick={() => setCurrentUser(null)}
          className="w-full bg-gray-100 text-red-600 py-4 rounded-2xl font-bold flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          Cerrar Sesión
        </button>
      </div>
    );
  };

  const renderDetail = () => {
    if (!viewingExpense) return null;
    
    // Mock history data for the detail view
    const history = [
      { date: '05 Feb', name: 'Juan Ferrari', amount: 'S/.100', status: 'Aprobado' },
      { date: '28 Ene', name: 'Carla Ruiz', amount: 'S/.95', status: 'Aprobado' },
      { date: '20 Ene', name: 'Juan Ferrari', amount: 'S/.130', status: 'Observado', alert: true },
      { date: '18 Ene', name: 'Carla Ruiz', amount: 'S/.95', status: 'Aprobado' },
      { date: '15 Ene', name: 'Jeny Novoa', amount: 'S/.250', status: 'Observado', alert: true },
      { date: '10 Ene', name: 'Juan Ferrari', amount: 'S/.36', status: 'Aprobado' },
      { date: '05 Ene', name: 'Carla Ruiz', amount: 'S/.88', status: 'Aprobado' },
      { date: '03 Ene', name: 'Carla Ruiz', amount: 'S/.36', status: 'Aprobado' },
    ];

    return (
      <motion.div 
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 100 }}
        className="fixed inset-0 z-50 bg-white overflow-y-auto"
      >
        {/* Header - Image 9 style */}
        <div className="bg-emerald-400 p-4 pt-10 flex items-center justify-between text-black">
          <ChevronLeft className="w-6 h-6" onClick={() => setViewingExpense(null)} />
          <h2 className="text-xl font-bold tracking-tight">DETALLE DE GASTO</h2>
          <div className="w-8 h-8 bg-black/10 rounded-full flex items-center justify-center" onClick={() => setViewingExpense(null)}>
            <XCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="p-0 space-y-0 pb-32">
          {/* Top Info Bar */}
          <div className="p-4 flex justify-between items-center text-sm border-b border-gray-100">
            <div className="flex items-center gap-2">
              <span className="text-gray-600">Estado:</span>
              <span className="bg-orange-400 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase">
                {viewingExpense.estado}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-gray-600">Descripción:</span>
              <span className="bg-cyan-400 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase">
                {viewingExpense.area}
              </span>
            </div>
          </div>

          {/* Amount and Category */}
          <div className="p-4 space-y-1">
            <p className="text-xl font-bold">S/. {viewingExpense.monto.toFixed(2)}</p>
            <p className="text-sm font-medium text-gray-700 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-black" />
              {viewingExpense.area}
            </p>
            <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
              <span>Comprobante :</span>
              <FileText className="w-4 h-4" />
            </div>
          </div>

          {/* Image Preview with Controls */}
          <div className="relative group">
            <img src={viewingExpense.evidencia_imagen} alt="Comprobante" className="w-full h-56 object-cover" />
            <div className="absolute top-4 right-4 flex gap-2">
              <button className="bg-black/40 backdrop-blur-md text-white px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1">
                <Search className="w-3 h-3" /> Zoom
              </button>
              <button className="bg-black/40 backdrop-blur-md text-white px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1">
                <Settings className="w-3 h-3" /> Rotar
              </button>
              <button className="bg-black/40 backdrop-blur-md text-white px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1">
                <UserIcon className="w-3 h-3" /> Ver original
              </button>
            </div>
          </div>

          {/* Risk Alerts Section - Image 9 style */}
          <div className="p-4 space-y-3">
            <div className="bg-red-600 text-white text-xs font-black px-4 py-1.5 rounded-lg w-fit uppercase italic tracking-tighter">
              ALTO
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-gray-800 border-b border-gray-100 pb-1">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span>Posible duplicidad</span>
                <span className="font-normal text-gray-500">(Hace 5 días)</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-gray-800 border-b border-gray-100 pb-1">
                <AlertCircle className="w-4 h-4 text-yellow-500" />
                <span>Compra recurrente</span>
                <span className="font-normal text-gray-500">(4 veces en 30 días)</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-gray-800 border-b border-gray-100 pb-1">
                <AlertCircle className="w-4 h-4 text-yellow-500" />
                <span>Fuera de política</span>
                <span className="font-normal text-gray-500">( {'>'} S/.100)</span>
              </div>
            </div>
            <button className="w-full text-center text-blue-600 text-xs font-bold py-1">
              Ver todas las alertas {'>'}
            </button>
          </div>

          {/* Data Table Section */}
          <div className="bg-gray-100 p-4">
            <h3 className="font-black text-sm uppercase tracking-tight mb-3">DATOS DEL GASTO</h3>
            <div className="bg-white rounded-xl overflow-hidden border border-gray-200">
              <div className="grid grid-cols-2 p-3 border-b border-gray-100 text-xs">
                <span className="text-gray-500">Solicitante:</span>
                <span className="font-bold text-right">Juan Ferrari</span>
              </div>
              <div className="grid grid-cols-2 p-3 border-b border-gray-100 text-xs">
                <span className="text-gray-500">Área:</span>
                <span className="font-bold text-right">Mantenimiento</span>
              </div>
              <div className="grid grid-cols-2 p-3 border-b border-gray-100 text-xs">
                <span className="text-gray-500">Categoría:</span>
                <span className="font-bold text-right">Repuestos/Wi-Fi</span>
              </div>
              <div className="grid grid-cols-2 p-3 border-b border-gray-100 text-xs">
                <span className="text-gray-500">Método:</span>
                <span className="font-bold text-right">Compra de conectores RJ45 + canaleta</span>
              </div>
              <div className="grid grid-cols-2 p-3 border-b border-gray-100 text-xs">
                <span className="text-gray-500">Monto registrado:</span>
                <span className="font-bold text-right text-blue-600 underline">S/.128.50 Ver más {'>'}</span>
              </div>
              <div className="grid grid-cols-2 p-3 text-xs items-center">
                <span className="text-gray-500">Monto del comprobante:</span>
                <div className="flex items-center justify-end gap-1 font-bold">
                  S/.128.50 <CheckCircle2 className="w-4 h-4 text-green-500" />
                </div>
              </div>
            </div>
          </div>

          {/* History Section */}
          <div className="p-4 space-y-4">
            <h3 className="font-black text-sm uppercase tracking-tight border-b-2 border-black pb-1">HISTORIAL</h3>
            <div className="space-y-0">
              {history.map((item, i) => (
                <div key={i} className="flex justify-between items-center py-2 border-b border-gray-100 text-[11px]">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500 w-12">{item.date}</span>
                    <ArrowRight className="w-3 h-3 text-gray-300" />
                    <span className="font-medium text-gray-700 w-20 truncate">{item.name}</span>
                    <span className="font-bold text-gray-900">● {item.amount}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {item.alert && <AlertCircle className="w-3 h-3 text-yellow-500" />}
                    <span className={cn(
                      "font-bold",
                      item.status === 'Aprobado' ? "text-green-600" : "text-yellow-600"
                    )}>{item.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Admin Actions - Floating Bottom Bar */}
        {isAdmin && (
          <div className="fixed bottom-0 left-0 right-0 bg-slate-900 p-4 space-y-3 safe-area-bottom z-50">
            {/* Image 9 style observation buttons */}
            <div className="flex gap-2">
              <button className="flex-1 py-2 bg-white/10 text-white rounded-lg text-[10px] font-bold border border-white/20">
                Solicitar comentario
              </button>
              <button className="flex-1 py-2 bg-white/10 text-white rounded-lg text-[10px] font-bold border border-white/20">
                Subir nueva foto
              </button>
              <button className="w-10 h-10 bg-emerald-500 text-white rounded-lg flex items-center justify-center">
                <ArrowRight className="w-5 h-5 -rotate-45" />
              </button>
            </div>
            
            {/* Final Decision Buttons */}
            <div className="flex gap-3">
              <button 
                onClick={() => handleUpdateStatus(viewingExpense.id, 'Rechazado', 'Gasto no cumple con las políticas de la empresa')}
                className="flex-1 py-3 bg-red-500 text-white rounded-xl font-bold text-xs shadow-lg shadow-red-500/20"
              >
                Rechazar
              </button>
              <button 
                onClick={() => handleUpdateStatus(viewingExpense.id, 'Aprobado')}
                className="flex-1 py-3 bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-lg shadow-emerald-500/20"
              >
                Aprobar Reembolso
              </button>
            </div>
          </div>
        )}
      </motion.div>
    );
  };

  const renderClosure = () => {
    return (
      <AnimatePresence>
        {isClosing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-white flex flex-col"
          >
            <div className="p-6 pt-12 flex items-center justify-between">
              <ChevronLeft className="w-6 h-6" onClick={() => setIsClosing(false)} />
              <h2 className="text-xl font-bold">Cierre diario</h2>
              <div className="w-6" />
            </div>

            <div className="p-4 space-y-6 flex-1 overflow-y-auto">
              <div className="text-center">
                <p className="text-gray-500 text-sm">viernes</p>
                <p className="text-xl font-bold">13 de febrero, 2026</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm space-y-2">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  </div>
                  <p className="text-gray-500 text-xs">Aprobados</p>
                  <p className="text-2xl font-bold">24</p>
                  <p className="text-[10px] text-gray-400">$125,400</p>
                </div>
                <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm space-y-2">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-bold">$</span>
                  </div>
                  <p className="text-gray-500 text-xs">Pagados</p>
                  <p className="text-2xl font-bold">18</p>
                  <p className="text-[10px] text-gray-400">$89,700</p>
                </div>
                <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm space-y-2">
                  <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                    <span className="text-orange-600 font-bold">!</span>
                  </div>
                  <p className="text-gray-500 text-xs">Observados</p>
                  <p className="text-2xl font-bold">5</p>
                  <p className="text-[10px] text-gray-400">$15,300</p>
                </div>
                <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm space-y-2">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                    <Clock className="w-5 h-5 text-gray-400" />
                  </div>
                  <p className="text-gray-500 text-xs">Pendientes</p>
                  <p className="text-2xl font-bold">12</p>
                  <p className="text-[10px] text-gray-400">$42,100</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold">Detalle por estado</h3>
                  <span className="text-[10px] text-gray-400">Últimos movimientos</span>
                </div>
                {[1, 2, 3].map(i => (
                  <div key={i} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm space-y-3">
                    <div className="flex justify-between items-start">
                      <p className="font-bold text-sm">Pago proveedores materiales</p>
                      <p className="font-bold text-sm">$15,400</p>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="flex gap-2">
                        <span className="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-[10px] font-bold">Compras</span>
                        <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-[10px] font-bold">Pagado</span>
                      </div>
                      <span className="text-[10px] text-gray-400">14:30</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 safe-area-bottom">
              <button 
                onClick={() => setIsClosing(false)}
                className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-200"
              >
                Generar Cierre
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    );
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-background-gradient flex flex-col items-center justify-center p-8 text-white">
        <div className="w-32 h-32 bg-white/20 rounded-full flex items-center justify-center mb-12 backdrop-blur-md">
          <UserIcon className="w-16 h-16 text-white" />
        </div>
        <div className="w-full space-y-4 max-w-xs">
          <div className="relative">
            <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input type="text" placeholder="Username" className="w-full bg-white/10 border border-white/30 rounded-full py-4 pl-12 pr-4 outline-none focus:bg-white/20 transition-all placeholder:text-white/60" />
          </div>
          <div className="relative">
            <Settings className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input type="password" placeholder="••••••••••••" className="w-full bg-white/10 border border-white/30 rounded-full py-4 pl-12 pr-4 outline-none focus:bg-white/20 transition-all placeholder:text-white/60" />
          </div>
          <p className="text-center text-xs opacity-75">¿Olvidaste tu contraseña?</p>
          
          <div className="flex justify-center gap-6 py-4">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center"><CheckCircle2 className="w-6 h-6" /></div>
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center"><CheckCircle2 className="w-6 h-6" /></div>
          </div>

          <button 
            onClick={() => setCurrentUser(MOCK_USERS[0])}
            className="w-full bg-blue-800 py-4 rounded-full font-bold shadow-xl active:scale-95 transition-transform"
          >
            Inicio de sesion
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 max-w-md mx-auto relative overflow-x-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'inicio' && renderInicio()}
          {activeTab === 'gastos' && renderGastos()}
          {activeTab === 'registrar' && renderRegistrar()}
          {activeTab === 'indicadores' && renderIndicadores()}
          {activeTab === 'perfil' && renderPerfil()}
        </motion.div>
      </AnimatePresence>

      <AnimatePresence>
        {viewingExpense && renderDetail()}
      </AnimatePresence>

      <AnimatePresence>
        {decisionFeedback && renderDecisionFeedback()}
      </AnimatePresence>

      {renderClosure()}

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900 text-gray-400 flex items-center justify-around py-3 px-2 bottom-nav-shadow rounded-t-[32px] z-40 safe-area-bottom max-w-md mx-auto">
        <button 
          onClick={() => setActiveTab('inicio')}
          className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === 'inicio' ? "text-blue-500" : "hover:text-white")}
        >
          <Home className="w-6 h-6" />
          <span className="text-[10px] font-bold">Inicio</span>
        </button>
        <button 
          onClick={() => setActiveTab('gastos')}
          className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === 'gastos' ? "text-blue-500" : "hover:text-white")}
        >
          <FileText className="w-6 h-6" />
          <span className="text-[10px] font-bold">Gastos</span>
        </button>
        
        <div className="relative -mt-12">
          <button 
            onClick={() => setActiveTab('registrar')}
            className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center shadow-lg shadow-blue-500/50 border-4 border-slate-900 active:scale-90 transition-transform"
          >
            <Plus className="w-8 h-8 text-white" />
          </button>
          <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-gray-400">Nuevo</span>
        </div>

        <button 
          onClick={() => setActiveTab('indicadores')}
          className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === 'indicadores' ? "text-blue-500" : "hover:text-white")}
        >
          <BarChart3 className="w-6 h-6" />
          <span className="text-[10px] font-bold">Indicadores</span>
        </button>
        <button 
          onClick={() => setActiveTab('perfil')}
          className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === 'perfil' ? "text-blue-500" : "hover:text-white")}
        >
          <UserIcon className="w-6 h-6" />
          <span className="text-[10px] font-bold">Perfil</span>
        </button>
      </nav>
    </div>
  );
}
